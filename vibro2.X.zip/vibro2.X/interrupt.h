#ifndef INTERRUPT_H
#define	INTERRUPT_H


#include <xc.h>
void StartMeasure (void);
void interrupt tc_int(void);

#endif	/* XC_HEADER_TEMPLATE_H */