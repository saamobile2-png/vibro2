opt subtitle "HI-TECH Software Omniscient Code Generator (Lite mode) build 9453"

opt pagewidth 120

	opt lm

	processor	16LF1827
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
indf	equ	0
indf0	equ	0
indf1	equ	1
pc	equ	2
pcl	equ	2
status	equ	3
fsr0l	equ	4
fsr0h	equ	5
fsr1l	equ	6
fsr1h	equ	7
bsr	equ	8
wreg	equ	9
intcon	equ	11
c	equ	1
z	equ	0
pclath	equ	10
# 6 "C:\__Soft\Vibro\main.c"
	psect config,class=CONFIG,delta=2 ;#
# 6 "C:\__Soft\Vibro\main.c"
	dw 0x0fc4 ;#
# 7 "C:\__Soft\Vibro\main.c"
	psect config,class=CONFIG,delta=2 ;#
# 7 "C:\__Soft\Vibro\main.c"
	dw 0x2eff ;#
	FNCALL	_main,_init
	FNCALL	_init,___awdiv
	FNROOT	_main
	FNCALL	intlevel1,_tc_int
	global	intlevel1
	FNROOT	intlevel1
	global	_PWRtick
	global	_PWM_REG
psect	nvCOMMON,class=COMMON,space=1
global __pnvCOMMON
__pnvCOMMON:
_PWM_REG:
       ds      1

	global	_TMR1
_TMR1	set	22
	global	_PR2
_PR2	set	27
	global	_T1CON
_T1CON	set	24
	global	_TMR2
_TMR2	set	26
	global	_CARRY
_CARRY	set	24
	global	_GIE
_GIE	set	95
	global	_PEIE
_PEIE	set	94
	global	_T2CKPS0
_T2CKPS0	set	224
	global	_T2CKPS1
_T2CKPS1	set	225
	global	_TMR1IF
_TMR1IF	set	136
	global	_TMR1ON
_TMR1ON	set	192
	global	_TMR2IF
_TMR2IF	set	137
	global	_TMR2ON
_TMR2ON	set	226
	global	_OSCCON
_OSCCON	set	153
	global	_TRISB
_TRISB	set	141
	global	_TMR1IE
_TMR1IE	set	1160
	global	_TMR2IE
_TMR2IE	set	1161
	global	_TRISA0
_TRISA0	set	1120
	global	_TRISA1
_TRISA1	set	1121
	global	_TRISA2
_TRISA2	set	1122
	global	_TRISB6
_TRISB6	set	1134
	global	_LATB
_LATB	set	269
	global	_LATA0
_LATA0	set	2144
	global	_EEADR
_EEADR	set	401
	global	_EECON1
_EECON1	set	405
	global	_EECON2
_EECON2	set	406
	global	_EEDATA
_EEDATA	set	403
	global	_ANSA0
_ANSA0	set	3168
	global	_RD
_RD	set	3240
	global	_WR
_WR	set	3241
	global	_WREN
_WREN	set	3242
	global	_CCP1CON
_CCP1CON	set	659
	global	_CCPR1L
_CCPR1L	set	657
	global	_PSTR1CON
_PSTR1CON	set	662
	file	"Vibro.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

psect	bitbssCOMMON,class=COMMON,bit,space=1
global __pbitbssCOMMON
__pbitbssCOMMON:
_PWRtick:
       ds      1

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2
	global __pbitbssCOMMON
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2
global end_of_initialization

;End of C runtime variable initialization code

end_of_initialization:
movlb 0
ljmp _main	;jump to C main() function
psect	cstackCOMMON,class=COMMON,space=1
global __pcstackCOMMON
__pcstackCOMMON:
	global	?_init
?_init:	; 0 bytes @ 0x0
	global	?_tc_int
?_tc_int:	; 0 bytes @ 0x0
	global	??_tc_int
??_tc_int:	; 0 bytes @ 0x0
	global	?_main
?_main:	; 0 bytes @ 0x0
	ds	1
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x1
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x1
	ds	2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x3
	ds	2
	global	??___awdiv
??___awdiv:	; 0 bytes @ 0x5
	ds	1
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	ds	1
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	ds	1
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	2
	global	??_init
??_init:	; 0 bytes @ 0xA
	ds	2
	global	??_main
??_main:	; 0 bytes @ 0xC
;;Data sizes: Strings 0, constant 0, data 0, bss 0, persistent 1 stack 0
;;Auto spaces:   Size  Autos    Used
;; COMMON          14     12      14
;; BANK0           80      0       0
;; BANK1           80      0       0
;; BANK2           80      0       0
;; BANK3           80      0       0
;; BANK4           48      0       0

;;
;; Pointer list with targets:

;; ?___awdiv	int  size(1) Largest target is 0
;;


;;
;; Critical Paths under _main in COMMON
;;
;;   _main->_init
;;   _init->___awdiv
;;
;; Critical Paths under _tc_int in COMMON
;;
;;   None.
;;
;; Critical Paths under _main in BANK0
;;
;;   None.
;;
;; Critical Paths under _tc_int in BANK0
;;
;;   None.
;;
;; Critical Paths under _main in BANK1
;;
;;   None.
;;
;; Critical Paths under _tc_int in BANK1
;;
;;   None.
;;
;; Critical Paths under _main in BANK2
;;
;;   None.
;;
;; Critical Paths under _tc_int in BANK2
;;
;;   None.
;;
;; Critical Paths under _main in BANK3
;;
;;   None.
;;
;; Critical Paths under _tc_int in BANK3
;;
;;   None.
;;
;; Critical Paths under _main in BANK4
;;
;;   None.
;;
;; Critical Paths under _tc_int in BANK4
;;
;;   None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;;
;;Call Graph Tables:
;;
;; ---------------------------------------------------------------------------------
;; (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;; ---------------------------------------------------------------------------------
;; (0) _main                                                 0     0      0     195
;;                               _init
;; ---------------------------------------------------------------------------------
;; (1) _init                                                 2     2      0     195
;;                                             10 COMMON     2     2      0
;;                            ___awdiv
;; ---------------------------------------------------------------------------------
;; (2) ___awdiv                                              9     5      4     195
;;                                              1 COMMON     9     5      4
;; ---------------------------------------------------------------------------------
;; Estimated maximum stack depth 2
;; ---------------------------------------------------------------------------------
;; (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;; ---------------------------------------------------------------------------------
;; (3) _tc_int                                               1     1      0       0
;;                                              0 COMMON     1     1      0
;; ---------------------------------------------------------------------------------
;; Estimated maximum stack depth 3
;; ---------------------------------------------------------------------------------

;; Call Graph Graphs:

;; _main (ROOT)
;;   _init
;;     ___awdiv
;;
;; _tc_int (ROOT)
;;

;; Address spaces:

;;Name               Size   Autos  Total    Cost      Usage
;;BIGRAM             170      0       0       0        0.0%
;;EEDATA             100      0       0       0        0.0%
;;NULL                 0      0       0       0        0.0%
;;CODE                 0      0       0       0        0.0%
;;BITCOMMON            E      0       1       1        7.1%
;;BITSFR0              0      0       0       1        0.0%
;;SFR0                 0      0       0       1        0.0%
;;COMMON               E      C       E       2      100.0%
;;BITSFR1              0      0       0       2        0.0%
;;SFR1                 0      0       0       2        0.0%
;;BITSFR2              0      0       0       3        0.0%
;;SFR2                 0      0       0       3        0.0%
;;STACK                0      0       2       3        0.0%
;;BITSFR3              0      0       0       4        0.0%
;;SFR3                 0      0       0       4        0.0%
;;ABS                  0      0       E       4        0.0%
;;BITBANK0            50      0       0       5        0.0%
;;BITSFR4              0      0       0       5        0.0%
;;SFR4                 0      0       0       5        0.0%
;;BANK0               50      0       0       6        0.0%
;;BITSFR5              0      0       0       6        0.0%
;;SFR5                 0      0       0       6        0.0%
;;BITBANK1            50      0       0       7        0.0%
;;BITSFR6              0      0       0       7        0.0%
;;SFR6                 0      0       0       7        0.0%
;;BANK1               50      0       0       8        0.0%
;;BITSFR7              0      0       0       8        0.0%
;;SFR7                 0      0       0       8        0.0%
;;BITBANK2            50      0       0       9        0.0%
;;BITSFR8              0      0       0       9        0.0%
;;SFR8                 0      0       0       9        0.0%
;;BANK2               50      0       0      10        0.0%
;;BITSFR9              0      0       0      10        0.0%
;;SFR9                 0      0       0      10        0.0%
;;BITBANK3            50      0       0      11        0.0%
;;BITSFR10             0      0       0      11        0.0%
;;SFR10                0      0       0      11        0.0%
;;BANK3               50      0       0      12        0.0%
;;BITSFR11             0      0       0      12        0.0%
;;SFR11                0      0       0      12        0.0%
;;BITBANK4            30      0       0      13        0.0%
;;BITSFR12             0      0       0      13        0.0%
;;SFR12                0      0       0      13        0.0%
;;BANK4               30      0       0      14        0.0%
;;BITSFR13             0      0       0      14        0.0%
;;SFR13                0      0       0      14        0.0%
;;BITSFR14             0      0       0      15        0.0%
;;SFR14                0      0       0      15        0.0%
;;DATA                 0      0      10      15        0.0%
;;BITSFR15             0      0       0      16        0.0%
;;SFR15                0      0       0      16        0.0%
;;BITSFR16             0      0       0      17        0.0%
;;SFR16                0      0       0      17        0.0%
;;BITSFR17             0      0       0      18        0.0%
;;SFR17                0      0       0      18        0.0%
;;BITSFR18             0      0       0      19        0.0%
;;SFR18                0      0       0      19        0.0%
;;BITSFR19             0      0       0      20        0.0%
;;SFR19                0      0       0      20        0.0%
;;BITSFR20             0      0       0      21        0.0%
;;SFR20                0      0       0      21        0.0%
;;BITSFR21             0      0       0      22        0.0%
;;SFR21                0      0       0      22        0.0%
;;BITSFR22             0      0       0      23        0.0%
;;SFR22                0      0       0      23        0.0%
;;BITSFR23             0      0       0      24        0.0%
;;SFR23                0      0       0      24        0.0%
;;BITSFR24             0      0       0      25        0.0%
;;SFR24                0      0       0      25        0.0%
;;BITSFR25             0      0       0      26        0.0%
;;SFR25                0      0       0      26        0.0%
;;BITSFR26             0      0       0      27        0.0%
;;SFR26                0      0       0      27        0.0%
;;BITSFR27             0      0       0      28        0.0%
;;SFR27                0      0       0      28        0.0%
;;BITSFR28             0      0       0      29        0.0%
;;SFR28                0      0       0      29        0.0%
;;BITSFR29             0      0       0      30        0.0%
;;SFR29                0      0       0      30        0.0%
;;BITSFR30             0      0       0      31        0.0%
;;SFR30                0      0       0      31        0.0%
;;BITSFR31             0      0       0      32        0.0%
;;SFR31                0      0       0      32        0.0%

	global	_main
psect	maintext,global,class=CODE,delta=2
global __pmaintext
__pmaintext:

;; *************** function _main *****************
;; Defined at:
;;		line 43 in file "C:\__Soft\Vibro\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;		None               void
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 17F/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2   BANK3   BANK4
;;      Params:         0       0       0       0       0       0
;;      Locals:         0       0       0       0       0       0
;;      Temps:          0       0       0       0       0       0
;;      Totals:         0       0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_init
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext
	file	"C:\__Soft\Vibro\main.c"
	line	43
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
	opt	stack 13
; Regs used in _main: [wreg+status,2+status,0+pclath+cstack]
	line	44
	
l6935:	
;main.c: 44: init();
	fcall	_init
	line	47
	
l6937:	
;main.c: 47: GIE = 1;
	bsf	(95/8),(95)&7
	line	48
	
l6939:	
;main.c: 48: PEIE = 1;
	bsf	(94/8),(94)&7
	line	50
	
l6941:	
;main.c: 50: TRISA1 = 1;
	movlb 1	; select bank1
	bsf	(1121/8)^080h,(1121)&7
	line	51
	
l6943:	
;main.c: 51: TRISA2 = 1;
	bsf	(1122/8)^080h,(1122)&7
	goto	l4308
	line	53
;main.c: 53: while(1){
	
l4307:	
	line	54
	
l4308:	
	line	53
	goto	l4308
	
l4309:	
	line	55
	
l4310:	
	global	start
	ljmp	start
	opt stack 0
GLOBAL	__end_of_main
	__end_of_main:
;; =============== function _main ends ============

	signat	_main,88
	global	_init
psect	text94,local,class=CODE,delta=2
global __ptext94
__ptext94:

;; *************** function _init *****************
;; Defined at:
;;		line 13 in file "C:\__Soft\Vibro\init.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;		None               void
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2   BANK3   BANK4
;;      Params:         0       0       0       0       0       0
;;      Locals:         0       0       0       0       0       0
;;      Temps:          2       0       0       0       0       0
;;      Totals:         2       0       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___awdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text94
	file	"C:\__Soft\Vibro\init.c"
	line	13
	global	__size_of_init
	__size_of_init	equ	__end_of_init-_init
	
_init:	
	opt	stack 13
; Regs used in _init: [wreg+status,2+status,0+pclath+cstack]
	line	14
	
l6901:	
;init.c: 14: PWM_REG = 51;
	movlw	(033h)
	movwf	(??_init+0)+0
	movf	(??_init+0)+0,w
	movwf	(_PWM_REG)
	line	15
;init.c: 15: OSCCON = 0b01110000;
	movlw	(070h)
	movlb 1	; select bank1
	movwf	(153)^080h	;volatile
	line	16
;init.c: 16: T1CON = 0b00110100;
	movlw	(034h)
	movlb 0	; select bank0
	movwf	(24)	;volatile
	line	17
	
l6903:	
;init.c: 17: TMR1ON = 0;
	bcf	(192/8),(192)&7
	line	18
	
l6905:	
;init.c: 18: TMR1 = 0x0000;
	clrf	(22)	;volatile
	clrf	(22+1)	;volatile
	line	19
	
l6907:	
;init.c: 19: TMR1IE = 1;
	movlb 1	; select bank1
	bsf	(1160/8)^080h,(1160)&7
	line	23
	
l6909:	
;init.c: 23: CCP1CON = 0b10001111;
	movlw	(08Fh)
	movlb 5	; select bank5
	movwf	(659)^0280h	;volatile
	line	24
	
l6911:	
;init.c: 24: PSTR1CON = 0b00010110;
	movlw	(016h)
	movwf	(662)^0280h	;volatile
	line	25
	
l6913:	
;init.c: 25: PR2 = PWM_REG;
	movf	(_PWM_REG),w
	movlb 0	; select bank0
	movwf	(27)	;volatile
	line	26
	
l6915:	
;init.c: 26: CCPR1L = PWM_REG/2;
	movlw	low(02h)
	movwf	(?___awdiv)
	movlw	high(02h)
	movwf	((?___awdiv))+1
	movf	(_PWM_REG),w
	movwf	(??_init+0)+0
	clrf	(??_init+0)+0+1
	movf	0+(??_init+0)+0,w
	movwf	0+(?___awdiv)+02h
	movf	1+(??_init+0)+0,w
	movwf	1+(?___awdiv)+02h
	fcall	___awdiv
	movf	(0+(?___awdiv)),w
	movlb 5	; select bank5
	movwf	(657)^0280h	;volatile
	line	27
	
l6917:	
;init.c: 27: T2CKPS1 = 0;
	movlb 0	; select bank0
	bcf	(225/8),(225)&7
	line	28
	
l6919:	
;init.c: 28: T2CKPS0 = 0;
	bcf	(224/8),(224)&7
	line	29
	
l6921:	
;init.c: 29: TMR2ON = 1;
	bsf	(226/8),(226)&7
	line	32
	
l6923:	
;init.c: 32: TRISA0 = 0;
	movlb 1	; select bank1
	bcf	(1120/8)^080h,(1120)&7
	line	33
	
l6925:	
;init.c: 33: ANSA0 = 0;
	movlb 3	; select bank3
	bcf	(3168/8)^0180h,(3168)&7
	line	34
	
l6927:	
;init.c: 34: LATA0 = 1;
	movlb 2	; select bank2
	bsf	(2144/8)^0100h,(2144)&7
	line	64
	
l6929:	
;init.c: 64: TRISB6 = 0;
	movlb 1	; select bank1
	bcf	(1134/8)^080h,(1134)&7
	line	65
	
l6931:	
;init.c: 65: TRISB = 0;
	clrf	(141)^080h	;volatile
	line	66
	
l6933:	
;init.c: 66: LATB = 0xff;
	movlw	(0FFh)
	movlb 2	; select bank2
	movwf	(269)^0100h	;volatile
	line	80
	
l1435:	
	return
	opt stack 0
GLOBAL	__end_of_init
	__end_of_init:
;; =============== function _init ends ============

	signat	_init,88
	global	___awdiv
psect	text95,local,class=CODE,delta=2
global __ptext95
__ptext95:

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 5 in file "C:\Program Files (x86)\HI-TECH Software\PICC\9.82\sources\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    1[COMMON] int 
;;  dividend        2    3[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    1[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2   BANK3   BANK4
;;      Params:         4       0       0       0       0       0
;;      Locals:         4       0       0       0       0       0
;;      Temps:          1       0       0       0       0       0
;;      Totals:         9       0       0       0       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_init
;; This function uses a non-reentrant model
;;
psect	text95
	file	"C:\Program Files (x86)\HI-TECH Software\PICC\9.82\sources\awdiv.c"
	line	5
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
	opt	stack 13
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	9
	
l6473:	
	clrf	(___awdiv@sign)
	line	10
	btfss	(___awdiv@divisor+1),7
	goto	u1091
	goto	u1090
u1091:
	goto	l6477
u1090:
	line	11
	
l6475:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	12
	clrf	(___awdiv@sign)
	bsf	status,0
	rlf	(___awdiv@sign),f
	goto	l6477
	line	13
	
l5775:	
	line	14
	
l6477:	
	btfss	(___awdiv@dividend+1),7
	goto	u1101
	goto	u1100
u1101:
	goto	l6483
u1100:
	line	15
	
l6479:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	16
	
l6481:	
	movlw	(01h)
	movwf	(??___awdiv+0)+0
	movf	(??___awdiv+0)+0,w
	xorwf	(___awdiv@sign),f
	goto	l6483
	line	17
	
l5776:	
	line	18
	
l6483:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	19
	
l6485:	
	movf	(___awdiv@divisor+1),w
	iorwf	(___awdiv@divisor),w
	skipnz
	goto	u1111
	goto	u1110
u1111:
	goto	l6505
u1110:
	line	20
	
l6487:	
	clrf	(___awdiv@counter)
	bsf	status,0
	rlf	(___awdiv@counter),f
	line	21
	goto	l6493
	
l5779:	
	line	22
	
l6489:	
	movlw	01h
	
u1125:
	lslf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	decfsz	wreg,f
	goto	u1125
	line	23
	
l6491:	
	movlw	(01h)
	movwf	(??___awdiv+0)+0
	movf	(??___awdiv+0)+0,w
	addwf	(___awdiv@counter),f
	goto	l6493
	line	24
	
l5778:	
	line	21
	
l6493:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u1131
	goto	u1130
u1131:
	goto	l6489
u1130:
	goto	l6495
	
l5780:	
	goto	l6495
	line	25
	
l5781:	
	line	26
	
l6495:	
	movlw	01h
	
u1145:
	lslf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	decfsz	wreg,f
	goto	u1145
	line	27
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u1155
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u1155:
	skipc
	goto	u1151
	goto	u1150
u1151:
	goto	l6501
u1150:
	line	28
	
l6497:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	subwfb	(___awdiv@dividend+1),f
	line	29
	
l6499:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	goto	l6501
	line	30
	
l5782:	
	line	31
	
l6501:	
	movlw	01h
	
u1165:
	lsrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	decfsz	wreg,f
	goto	u1165
	line	32
	
l6503:	
	movlw	low(01h)
	subwf	(___awdiv@counter),f
	btfss	status,2
	goto	u1171
	goto	u1170
u1171:
	goto	l6495
u1170:
	goto	l6505
	
l5783:	
	goto	l6505
	line	33
	
l5777:	
	line	34
	
l6505:	
	movf	(___awdiv@sign),w
	skipz
	goto	u1180
	goto	l6509
u1180:
	line	35
	
l6507:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	goto	l6509
	
l5784:	
	line	36
	
l6509:	
	movf	(___awdiv@quotient+1),w
	clrf	(?___awdiv+1)
	addwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	clrf	(?___awdiv)
	addwf	(?___awdiv)

	goto	l5785
	
l6511:	
	line	37
	
l5785:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
;; =============== function ___awdiv ends ============

	signat	___awdiv,8314
	global	_tc_int
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:

;; *************** function _tc_int *****************
;; Defined at:
;;		line 16 in file "C:\__Soft\Vibro\interrupt.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;		None               void
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2   BANK3   BANK4
;;      Params:         0       0       0       0       0       0
;;      Locals:         0       0       0       0       0       0
;;      Temps:          1       0       0       0       0       0
;;      Totals:         1       0       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	intentry
	file	"C:\__Soft\Vibro\interrupt.c"
	line	16
	global	__size_of_tc_int
	__size_of_tc_int	equ	__end_of_tc_int-_tc_int
	
_tc_int:	
	opt	stack 13
; Regs used in _tc_int: [wreg+status,2]
psect	intentry
	pagesel	$
	movlb 0	; select bank0
	movf	btemp+1,w
	movwf	(??_tc_int+0)
	line	22
	
i1l6013:	
;interrupt.c: 22: if(TMR2IF && TMR2IE)
	btfss	(137/8),(137)&7
	goto	u1_21
	goto	u1_20
u1_21:
	goto	i1l6021
u1_20:
	
i1l6015:	
	movlb 1	; select bank1
	btfss	(1161/8)^080h,(1161)&7
	goto	u2_21
	goto	u2_20
u2_21:
	goto	i1l6021
u2_20:
	line	24
	
i1l6017:	
;interrupt.c: 23: {
;interrupt.c: 24: TMR2IF = 0;
	movlb 0	; select bank0
	bcf	(137/8),(137)&7
	line	25
	
i1l6019:	
;interrupt.c: 25: TMR2 = 0xff-10;
	movlw	(0F5h)
	movwf	(26)	;volatile
	line	26
;interrupt.c: 26: PWRtick =~PWRtick;
	movlw	1<<((_PWRtick)&7)
	xorwf	((_PWRtick)/8),f
	goto	i1l6021
	line	30
	
i1l2870:	
	line	32
	
i1l6021:	
;interrupt.c: 30: };
;interrupt.c: 32: if(TMR1IF && TMR1IE){
	movlb 0	; select bank0
	btfss	(136/8),(136)&7
	goto	u3_21
	goto	u3_20
u3_21:
	goto	i1l2872
u3_20:
	
i1l6023:	
	movlb 1	; select bank1
	btfss	(1160/8)^080h,(1160)&7
	goto	u4_21
	goto	u4_20
u4_21:
	goto	i1l2872
u4_20:
	line	33
	
i1l6025:	
;interrupt.c: 33: TMR1IF = 0;
	movlb 0	; select bank0
	bcf	(136/8),(136)&7
	line	34
	
i1l6027:	
;interrupt.c: 34: TMR1 = 0x0000;
	clrf	(22)	;volatile
	clrf	(22+1)	;volatile
	goto	i1l2872
	line	35
	
i1l2871:	
	line	38
	
i1l2872:	
	movf	(??_tc_int+0),w
	movlb 0	; select bank0
	movwf	btemp+1
	retfie
	opt stack 0
GLOBAL	__end_of_tc_int
	__end_of_tc_int:
;; =============== function _tc_int ends ============

	signat	_tc_int,88
psect	intentry
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp
	end
