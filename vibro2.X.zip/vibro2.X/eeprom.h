#ifndef EEPROM_H
#define	EEPROM_H

unsigned char EE_LABEL;
unsigned char EE_ADRESS_CUR;
extern unsigned char EEPROM_ReadByte(unsigned int adr);
char CheckCurTable (void);
void EEPROM_WriteByte(unsigned int adr, unsigned char data);
void ReadTable (void);
void SetDefaultTable (void);

#endif
