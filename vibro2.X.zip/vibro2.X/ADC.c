#include <xc.h>
//#include "time_delay.h"
#include "main.h"

unsigned int READ_ADC(unsigned char channel){
    unsigned int RES = 0;
    ADCON0bits.CHS = channel;
    NOP();
    NOP();
    NOP();
    GO = 1;
    while(GO){    };

    return ADRES;
};
