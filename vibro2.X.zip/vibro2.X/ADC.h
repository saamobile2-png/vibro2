#ifndef ADC_H
#define	ADC_H

unsigned int READ_ADC(unsigned char channel);
//unsigned int read_ULine(void);

//unsigned int read_UTemp(void);
//unsigned int read_ULine(void);

#endif