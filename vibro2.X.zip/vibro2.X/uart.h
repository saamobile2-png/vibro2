#ifndef UART_H
#define UART_H
#include <stdint.h>
#include <stdbool.h>
void USART_Transmit_BYTE(unsigned char byte);
/*void USART_Transmit_WORD(WORD tx_word);
void USART_Transmit_DWORD(unsigned long tx_word);*/
void USART_Transmit_Str(char *str_buff);
void USART_INIT (void);
void USART_Transmit_INT (unsigned long data, unsigned char i, unsigned char dec, unsigned char nul);
void uart_put_crlf(void);
void uart_put_u16(uint16_t value);
void uart_puts(const char *s);
void uart_putc(char c);
bool ParseAsciiMessageToGlobalTable(const char *rxBuf, uint16_t row);
#endif