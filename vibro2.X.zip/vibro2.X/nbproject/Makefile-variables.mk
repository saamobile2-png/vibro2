#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=vibro2.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/vibro2.X.production.hex
# new configuration
CND_ARTIFACT_DIR_new=dist/new/production
CND_ARTIFACT_NAME_new=vibro2.X.production.hex
CND_ARTIFACT_PATH_new=dist/new/production/vibro2.X.production.hex
