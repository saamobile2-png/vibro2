/*
 * File:   terminal.c
 * Author: User
 *
 * Created on 3 ������� 2025 �., 8:49
 */


#include <xc.h>
#include "main.h"
#include "uart.h"
bit LED_RED_old;
bit TimeOut_old;
BYTE Line, Sym;
bit tick_terminal;
void Terminal(void) {
    uart_put_u16(TableLabel);
    if(SuperMode)   uart_puts("*");
    uart_puts(" F=");
    uart_put_u16(F);
    uart_puts("; F");
    uart_put_u16(DENSITY);
    uart_puts("=");
    uart_put_u16(Threshold);
    uart_puts(";");
    uart_put_crlf();
}
void BlockTerminal(void) {
    uart_put_u16(TableLabel);
    if(SuperMode)   uart_puts("*");
    uart_puts(" F=");
    uart_put_u16(F);
    uart_puts("; F0=");
    uart_put_u16(Table[TableLabel][0]);
    uart_puts(";");
    uart_put_crlf();
}
void DefTerminal(void) {
    uart_put_u16(TableLabel);
    if(SuperMode)   uart_puts("*");
    uart_puts(" F=");
    uart_put_u16(F);
    uart_puts("; F");
    if(INVERT){
        uart_put_u16(DENSITY);
        uart_puts("=");
        uart_put_u16(Table[TableLabel][DENSITY]);
    }else{
        if(DENSITY == 1)    uart_put_u16(0);
        if(DENSITY == 2)    uart_put_u16(3);
        uart_puts("=");
        if(DENSITY == 1)    uart_put_u16(Table[TableLabel][0]);
        if(DENSITY == 2)    uart_put_u16(Table[TableLabel][3]);
    }
    uart_puts(";");
    uart_put_crlf();
}
void SuperUserTerminal(void) {
    uart_put_u16(TableLabel);
    if(SuperMode)   uart_puts("*");
    uart_puts(" F=");
    uart_put_u16(F);
    uart_puts("; F0=");
    uart_put_u16(Table[TableLabel][0]);
    uart_puts("; F1=");
    uart_put_u16(Table[TableLabel][1]);
    uart_puts("; F2=");
    uart_put_u16(Table[TableLabel][2]);
    uart_puts("; F3=");
    uart_put_u16(Table[TableLabel][3]);
    if(TableLabel == 1){
        uart_puts(";");
    }else if(TableLabel == 2){
        uart_puts("; T=");
        uart_put_u16(Table[TableLabel][4]);
        uart_puts(";");
    };
    uart_put_crlf();
}
