
#ifndef INIT_H
#define	INIT_H


#include <htc.h>

void init (void);

#endif	/* XC_HEADER_TEMPLATE_H */

