#include <xc.h>
#include "types.h"
#include "uart.h"

static volatile BYTE g_rxBuf[UART_RX_BUF_SIZE];
static volatile BYTE g_rxIndex = 0u;
static volatile BYTE g_rxPrev = 0u;
static volatile BYTE g_rxReady = 0u;

static void UART_SkipSpaces(const BYTE **p)
{
    while ((**p == ' ') || (**p == '\t'))
    {
        (*p)++;
    }
}

static BYTE UART_ParseName(const BYTE **p, const char *name)
{
    BYTE i = 0u;
    while (name[i] != '\0')
    {
        if ((*p)[i] != (BYTE)name[i])
        {
            return FALSE;
        }
        i++;
    }
    *p += i;
    return TRUE;
}

static BYTE UART_ParseWordValue(const BYTE **p, WORD *value)
{
    WORD v = 0u;
    BYTE found = 0u;
    BYTE c;

    while (((c = **p) >= '0') && (c <= '9'))
    {
        found = 1u;
        v = (WORD)(v * 10u + (WORD)(c - '0'));
        (*p)++;
    }

    if (found == 0u)
    {
        return FALSE;
    }

    *value = v;
    return TRUE;
}

static BYTE UART_ParseField(const BYTE **p, const char *name, WORD *value)
{
    UART_SkipSpaces(p);

    if (UART_ParseName(p, name) == FALSE)
    {
        return FALSE;
    }

    UART_SkipSpaces(p);
    if (**p != '=')
    {
        return FALSE;
    }
    (*p)++;

    UART_SkipSpaces(p);
    if (UART_ParseWordValue(p, value) == FALSE)
    {
        return FALSE;
    }

    UART_SkipSpaces(p);
    if (**p != ';')
    {
        return FALSE;
    }
    (*p)++;

    return TRUE;
}

void UART_Init(void)
{
    TRISBbits.TRISB1 = 1;
    TRISBbits.TRISB2 = 0;

    APFCON0bits.RXDTSEL = 0;
    APFCON1bits.TXCKSEL = 0;

    BAUDCONbits.BRG16 = 1;
    TXSTAbits.BRGH = 1;
    SPBRGH = 0u;
    SPBRGL = 12u;

    TXSTAbits.SYNC = 0;
    RCSTAbits.SPEN = 1;
    TXSTAbits.TXEN = 1;
    RCSTAbits.CREN = 1;

    PIE1bits.RCIE = 1;
}

void UART_RxISR(BYTE c)
{
    if (g_rxReady != 0u)
    {
        return;
    }

    if (g_rxIndex < (UART_RX_BUF_SIZE - 1u))
    {
        g_rxBuf[g_rxIndex] = c;
        g_rxIndex++;

        if ((g_rxPrev == '\r') && (c == '\n'))
        {
            if (g_rxIndex >= 2u)
            {
                g_rxBuf[g_rxIndex - 2u] = 0u;
            }
            else
            {
                g_rxBuf[0] = 0u;
            }

            g_rxReady = 1u;
            g_rxIndex = 0u;
            g_rxPrev = 0u;
            return;
        }

        g_rxPrev = c;
    }
    else
    {
        g_rxIndex = 0u;
        g_rxPrev = 0u;
    }
}

BYTE UART_HasLine(void)
{
    return g_rxReady;
}

void UART_DropLine(void)
{
    g_rxReady = 0u;
}

BYTE UART_ParseLine(UART_COMMAND *cmd)
{
    const BYTE *p;
    WORD temp;
    WORD tval;

    cmd->type = UART_CMD_NONE;
    cmd->tableIndex = 0u;

    if (g_rxReady == 0u)
    {
        return FALSE;
    }

    p = (const BYTE *)g_rxBuf;
    UART_SkipSpaces(&p);

    if (UART_ParseName(&p, "Table") != FALSE)
    {
        UART_SkipSpaces(&p);
        if (*p != '=')
        {
            return FALSE;
        }
        p++;

        if (UART_ParseWordValue(&p, &temp) == FALSE)
        {
            return FALSE;
        }

        UART_SkipSpaces(&p);
        if (*p != ';')
        {
            return FALSE;
        }

        cmd->type = UART_CMD_SET_TABLE;
        cmd->tableIndex = (BYTE)temp;
        return TRUE;
    }

    if (UART_ParseField(&p, "F0", &cmd->table.f0) == FALSE) return FALSE;
    if (UART_ParseField(&p, "F1", &cmd->table.f1) == FALSE) return FALSE;
    if (UART_ParseField(&p, "F2", &cmd->table.f2) == FALSE) return FALSE;
    if (UART_ParseField(&p, "F3", &cmd->table.f3) == FALSE) return FALSE;
    if (UART_ParseField(&p, "T",  &tval) == FALSE) return FALSE;

    cmd->table.t_ms = tval;
    cmd->type = UART_CMD_SET_TABLE2_VALUES;
    return TRUE;
}

void UART_PutChar(char c)
{
    while (PIR1bits.TXIF == 0)
    {
    }
    TXREG = c;
}

void UART_PutCRLF(void)
{
    UART_PutChar('\r');
    UART_PutChar('\n');
}

void UART_PutString(const char *s)
{
    while (*s != '\0')
    {
        UART_PutChar(*s);
        s++;
    }
}

void UART_PutWord(WORD v)
{
    char buf[6];
    BYTE i = 0u;
    BYTE j;

    if (v == 0u)
    {
        UART_PutChar('0');
        return;
    }

    while (v != 0u)
    {
        buf[i] = (char)('0' + (v % 10u));
        v /= 10u;
        i++;
    }

    for (j = i; j > 0u; j--)
    {
        UART_PutChar(buf[j - 1u]);
    }
}
