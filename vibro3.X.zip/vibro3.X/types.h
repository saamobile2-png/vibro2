#ifndef TYPES_H
#define TYPES_H

#include <xc.h>

typedef unsigned char  BYTE;
typedef unsigned int   WORD;
typedef unsigned long  DWORD;

#define TRUE  1u
#define FALSE 0u

#define TABLE_COUNT 3u

#define ADC_POS1_MAX  341u
#define ADC_POS2_MIN  342u
#define ADC_POS2_MAX  682u
#define ADC_POS3_MIN  683u

#define TIME_MAX_MS   30000u

typedef struct
{
    WORD f0;
    WORD f1;
    WORD f2;
    WORD f3;
    WORD t_ms;
} PARAM_TABLE;

typedef enum
{
    APP_MODE_RUN = 0,
    APP_MODE_USER = 1,
    APP_MODE_FACTORY = 2
} APP_MODE;

typedef enum
{
    ENTER_NONE = 0,
    ENTER_USER_WAIT3,
    ENTER_USER_WAIT1,
    ENTER_FACTORY_WAIT3,
    ENTER_FACTORY_WAIT1
} ENTER_STATE;

typedef enum
{
    ADC_POS_UNKNOWN = 0,
    ADC_POS_1,
    ADC_POS_2,
    ADC_POS_3
} ADC_POSITION;

#endif
