#include "types.h"
#include "platform.h"
#include "adc.h"
#include "uart.h"
#include "eeprom.h"
#include "app.h"

static PARAM_TABLE g_tables[TABLE_COUNT];
static BYTE g_activeTable = 0u;
static APP_MODE g_mode = APP_MODE_RUN;
static ENTER_STATE g_enterState = ENTER_NONE;

static BYTE g_lastRb0 = 1u;
static BYTE g_lastRa0 = 1u;
static BYTE g_lastRa2 = 0u;
static BYTE g_lastRa3 = 0u;

static WORD g_adcValue = 0u;
static ADC_POSITION g_adcPos = ADC_POS_UNKNOWN;
static WORD g_timeMs = 0u;

static WORD g_freq = 0u;
static WORD g_selectedFy = 0u;

static BYTE g_alarmLow = 0u;
static BYTE g_alarmHigh = 0u;
static BYTE g_alarmRequest = 0u;

static BYTE g_normalStateMax = 0u;
static BYTE g_targetNormalStateMax = 0u;
static DWORD g_switchStartMs = 0ul;
static BYTE g_switchPending = 0u;

static BYTE g_alarmStage = 0u;
static DWORD g_alarmStageMs = 0ul;

static DWORD g_lastAdcMs = 0ul;
static DWORD g_lastTelemetryMs = 0ul;
static DWORD g_lastBlinkMs = 0ul;
static BYTE g_blinkPhase = 0u;

static DWORD g_inactivityStartMs = 0ul;
static BYTE g_recording = 0u;
static DWORD g_recordCount = 0ul;
static DWORD g_recordSum = 0ul;

static void APP_UpdateADC(void);
static void APP_UpdateMeasurement(void);
static void APP_UpdateModeRequests(void);
static void APP_UpdateServiceMode(void);
static void APP_UpdateNormalLogic(void);
static void APP_UpdateAlarm(void);
static void APP_ApplyOutputs(void);
static void APP_SendTelemetry(void);
static void APP_HandleUART(void);
static void APP_EnterMode(APP_MODE mode);
static void APP_ExitMode(void);
static void APP_StartRecording(void);
static void APP_StopRecording(void);
static void APP_ResetInactivity(void);
static BYTE APP_IsInNormalRange(void);
static BYTE APP_GetEffectiveLogic(void);
static PARAM_TABLE *APP_Table(void);

void APP_Init(void)
{
    EEPROM_InitDefaults(g_tables, &g_activeTable);

    if (g_activeTable >= TABLE_COUNT)
    {
        g_activeTable = 0u;
    }

    Platform_FreqStart();
    APP_UpdateADC();
    g_lastRa2 = Platform_ReadRA2();
    g_lastRa3 = Platform_ReadRA3();

    Platform_SetGreenLed(FALSE);
    Platform_SetRedLed(FALSE);
    Platform_SetNormalCurrentMax(FALSE);
    Platform_SetAlarmMode(FALSE);
    Platform_SetAlarmCurrent(FALSE);
}

void APP_Task(void)
{
    DWORD now;

    now = Platform_GetMs();

    if ((now - g_lastAdcMs) >= 1000ul)
    {
        g_lastAdcMs = now;
        APP_UpdateADC();
    }

    APP_UpdateMeasurement();
    APP_HandleUART();
    APP_UpdateModeRequests();
    APP_UpdateServiceMode();
    APP_UpdateNormalLogic();
    APP_UpdateAlarm();
    APP_ApplyOutputs();

    {
        DWORD blinkHalfPeriod;

        blinkHalfPeriod = 500ul;
        if (((g_mode == APP_MODE_USER) || (g_mode == APP_MODE_FACTORY)) && (g_recording != 0u))
        {
            blinkHalfPeriod = 1000ul;
        }

        if ((now - g_lastBlinkMs) >= blinkHalfPeriod)
        {
            g_lastBlinkMs = now;
            g_blinkPhase ^= 1u;
        }
    }

    if ((now - g_lastTelemetryMs) >= 1000ul)
    {
        g_lastTelemetryMs = now;
        APP_SendTelemetry();
    }
}

static BYTE APP_GetEffectiveLogic(void)
{
    BYTE logic;

    logic = Platform_ReadRA3();
    if (Platform_ReadRB0() == 0u)
    {
        logic ^= 1u;
    }

    return logic;
}

static PARAM_TABLE *APP_Table(void)
{
    return &g_tables[g_activeTable];
}

static void APP_UpdateADC(void)
{
    g_adcValue = ADC_ReadAN1();
    g_adcPos = ADC_GetPosition(g_adcValue);

    if (g_activeTable < 2u)
    {
        g_timeMs = ADC_ToTimeMs(g_adcValue);
    }
    else
    {
        g_timeMs = APP_Table()->t_ms;
    }

    if (g_timeMs > TIME_MAX_MS)
    {
        g_timeMs = 0u;
    }
}

static void APP_UpdateMeasurement(void)
{
    if (Platform_FreqReady() != 0u)
    {
        g_freq = Platform_FreqGetHz();
        Platform_FreqStart();
    }
}

static BYTE APP_IsInNormalRange(void)
{
    PARAM_TABLE *t;
    t = APP_Table();
    return (BYTE)((g_freq >= t->f0) && (g_freq <= t->f3));
}

static void APP_UpdateModeRequests(void)
{
    BYTE rb0;
    BYTE ra0;

    rb0 = Platform_ReadRB0();
    ra0 = Platform_ReadRA0();

    if (g_mode == APP_MODE_RUN)
    {
        if ((g_lastRb0 != 0u) && (rb0 == 0u))
        {
            g_enterState = ENTER_USER_WAIT3;
        }

        if ((g_lastRa0 != 0u) && (ra0 == 0u))
        {
            g_enterState = ENTER_FACTORY_WAIT3;
        }

        if (g_enterState == ENTER_USER_WAIT3)
        {
            if (g_adcPos == ADC_POS_3)
            {
                g_enterState = ENTER_USER_WAIT1;
            }
            else if (rb0 != 0u)
            {
                g_enterState = ENTER_NONE;
            }
        }
        else if (g_enterState == ENTER_USER_WAIT1)
        {
            if (g_adcPos == ADC_POS_1)
            {
                APP_EnterMode(APP_MODE_USER);
                g_enterState = ENTER_NONE;
            }
            else if (rb0 != 0u)
            {
                g_enterState = ENTER_NONE;
            }
        }
        else if (g_enterState == ENTER_FACTORY_WAIT3)
        {
            if (g_adcPos == ADC_POS_3)
            {
                g_enterState = ENTER_FACTORY_WAIT1;
            }
            else if (ra0 != 0u)
            {
                g_enterState = ENTER_NONE;
            }
        }
        else if (g_enterState == ENTER_FACTORY_WAIT1)
        {
            if (g_adcPos == ADC_POS_1)
            {
                APP_EnterMode(APP_MODE_FACTORY);
                g_enterState = ENTER_NONE;
            }
            else if (ra0 != 0u)
            {
                g_enterState = ENTER_NONE;
            }
        }
    }

    g_lastRb0 = rb0;
    g_lastRa0 = ra0;
}

static void APP_EnterMode(APP_MODE mode)
{
    g_mode = mode;
    g_recording = 0u;
    g_recordCount = 0ul;
    g_recordSum = 0ul;
    APP_ResetInactivity();

    if (mode == APP_MODE_USER)
    {
        g_activeTable = 1u;
    }
    else if (mode == APP_MODE_FACTORY)
    {
        g_activeTable = 2u;
    }

    EEPROM_SaveActiveTable(g_activeTable);
}

static void APP_ExitMode(void)
{
    if ((g_adcPos == ADC_POS_2) && (g_activeTable > 0u))
    {
        g_activeTable--;
        EEPROM_SaveActiveTable(g_activeTable);
    }

    g_mode = APP_MODE_RUN;
    g_recording = 0u;
    g_recordCount = 0ul;
    g_recordSum = 0ul;
}

static void APP_ResetInactivity(void)
{
    g_inactivityStartMs = Platform_GetMs();
}

static void APP_StartRecording(void)
{
    g_recording = 1u;
    g_recordCount = 0ul;
    g_recordSum = 0ul;
    APP_ResetInactivity();
}

static void APP_StopRecording(void)
{
    WORD favg;
    PARAM_TABLE *t;

    if (g_recording == 0u)
    {
        return;
    }

    g_recording = 0u;

    if (g_recordCount == 0ul)
    {
        return;
    }

    favg = (WORD)(g_recordSum / g_recordCount);
    t = APP_Table();

    t->f1 = favg;
    t->f2 = favg;
    t->f0 = (WORD)(favg + 25u);
    t->f3 = (WORD)(favg + 20u);

    EEPROM_SaveTable(g_activeTable, t);
}

static void APP_UpdateServiceMode(void)
{
    DWORD now;
    BYTE rb0;
    BYTE ra0;

    now = Platform_GetMs();

    if ((g_mode != APP_MODE_USER) && (g_mode != APP_MODE_FACTORY))
    {
        return;
    }

    rb0 = Platform_ReadRB0();
    ra0 = Platform_ReadRA0();

    if ((g_mode == APP_MODE_USER) && (g_lastRb0 != 0u) && (rb0 == 0u))
    {
        APP_ExitMode();
        g_lastRb0 = rb0;
        g_lastRa0 = ra0;
        return;
    }

    if ((g_mode == APP_MODE_FACTORY) && (g_lastRa0 != 0u) && (ra0 == 0u))
    {
        APP_ExitMode();
        g_lastRb0 = rb0;
        g_lastRa0 = ra0;
        return;
    }

    if (g_adcPos == ADC_POS_3)
    {
        APP_ResetInactivity();
    }

    if ((g_adcPos == ADC_POS_1) || (g_adcPos == ADC_POS_2))
    {
        if ((now - g_inactivityStartMs) >= 60000ul)
        {
            APP_ExitMode();
            g_lastRb0 = rb0;
            g_lastRa0 = ra0;
            return;
        }
    }

    if ((g_recording == 0u) && (g_adcPos == ADC_POS_3))
    {
        APP_StartRecording();
    }
    else if ((g_recording != 0u) && (g_adcPos == ADC_POS_1))
    {
        APP_StopRecording();
    }

    if (g_recording != 0u)
    {
        g_recordSum += g_freq;
        g_recordCount++;
    }

    g_lastRb0 = rb0;
    g_lastRa0 = ra0;
}

static void APP_UpdateNormalLogic(void)
{
    PARAM_TABLE *t;
    BYTE ra2;
    BYTE effectiveLogic;
    BYTE above;
    BYTE nextStateMax;
    DWORD now;

    t = APP_Table();
    ra2 = Platform_ReadRA2();
    effectiveLogic = APP_GetEffectiveLogic();
    now = Platform_GetMs();

    if (ra2 == 0u)
    {
        g_selectedFy = t->f2;
    }
    else
    {
        g_selectedFy = t->f1;
    }

    g_alarmLow  = (BYTE)(g_freq < t->f0);
    g_alarmHigh = (BYTE)(g_freq > t->f3);
    g_alarmRequest = (BYTE)((g_alarmLow != 0u) || (g_alarmHigh != 0u));

    if (g_alarmRequest != 0u)
    {
        g_switchPending = 0u;
        return;
    }

    above = (BYTE)(g_freq > g_selectedFy);
    nextStateMax = (BYTE)((above == effectiveLogic) ? 1u : 0u);

    if (nextStateMax != g_targetNormalStateMax)
    {
        g_targetNormalStateMax = nextStateMax;
        g_switchPending = 1u;
        g_switchStartMs = now;
    }

    if ((g_switchPending != 0u) && ((now - g_switchStartMs) >= g_timeMs))
    {
        g_normalStateMax = g_targetNormalStateMax;
        g_switchPending = 0u;
    }
}

static void APP_UpdateAlarm(void)
{
    DWORD now;

    now = Platform_GetMs();

    if (g_alarmRequest != 0u)
    {
        if (g_alarmStage == 0u)
        {
            Platform_SetAlarmMode(TRUE);
            g_alarmStage = 1u;
            g_alarmStageMs = now;
        }
        else if ((g_alarmStage == 1u) && ((now - g_alarmStageMs) >= 100ul))
        {
            Platform_SetAlarmCurrent(TRUE);
            g_alarmStage = 2u;
        }
    }
    else
    {
        if (g_alarmStage == 2u)
        {
            Platform_SetAlarmCurrent(FALSE);
            g_alarmStage = 3u;
            g_alarmStageMs = now;
        }
        else if ((g_alarmStage == 3u) && ((now - g_alarmStageMs) >= 100ul))
        {
            Platform_SetAlarmMode(FALSE);
            g_alarmStage = 0u;
        }
    }
}

static void APP_ApplyOutputs(void)
{
    if (g_alarmRequest != 0u)
    {
        if (g_alarmLow != 0u)
        {
            Platform_SetGreenLed(FALSE);
            Platform_SetRedLed(g_blinkPhase);
        }
        else
        {
            Platform_SetGreenLed(g_blinkPhase);
            Platform_SetRedLed(FALSE);
        }
        return;
    }

    if ((g_mode == APP_MODE_USER) || (g_mode == APP_MODE_FACTORY))
    {
        Platform_SetGreenLed(g_blinkPhase);
        Platform_SetRedLed((BYTE)(g_blinkPhase == 0u ? 1u : 0u));
        Platform_SetNormalCurrentMax(g_normalStateMax);
        return;
    }

    if (g_normalStateMax != 0u)
    {
        Platform_SetNormalCurrentMax(TRUE);
        Platform_SetGreenLed(FALSE);
        Platform_SetRedLed(TRUE);
    }
    else
    {
        Platform_SetNormalCurrentMax(FALSE);
        Platform_SetGreenLed(TRUE);
        Platform_SetRedLed(FALSE);
    }
}

static void APP_SendTelemetry(void)
{
    PARAM_TABLE *t;
    BYTE ra2;
    BYTE effectiveLogic;

    t = APP_Table();
    ra2 = Platform_ReadRA2();
    effectiveLogic = APP_GetEffectiveLogic();

    UART_PutWord((WORD)g_activeTable);
    UART_PutChar(' ');
    UART_PutChar('F');
    UART_PutChar('=');
    UART_PutWord(g_freq);
    UART_PutChar(';');
    UART_PutChar(' ');

    if (g_alarmLow != 0u)
    {
        UART_PutString("F0=");
        UART_PutWord(t->f0);
    }
    else if (g_alarmHigh != 0u)
    {
        UART_PutString("F3=");
        UART_PutWord(t->f3);
    }
    else if ((g_mode == APP_MODE_USER) || (g_mode == APP_MODE_FACTORY))
    {
        if (effectiveLogic == 0u)
        {
            if (ra2 == 0u)
            {
                UART_PutString("F2=");
                UART_PutWord(t->f2);
            }
            else
            {
                UART_PutString("F1=");
                UART_PutWord(t->f1);
            }
        }
        else
        {
            if (ra2 == 0u)
            {
                UART_PutString("F3=");
                UART_PutWord(t->f3);
            }
            else
            {
                UART_PutString("F0=");
                UART_PutWord(t->f0);
            }
        }
    }
    else
    {
        if (g_selectedFy == t->f1)
        {
            UART_PutString("F1=");
            UART_PutWord(t->f1);
        }
        else
        {
            UART_PutString("F2=");
            UART_PutWord(t->f2);
        }
    }

    UART_PutChar(';');
    UART_PutCRLF();
}

static void APP_HandleUART(void)
{
    UART_COMMAND cmd;

    if (UART_HasLine() == 0u)
    {
        return;
    }

    if (UART_ParseLine(&cmd) != 0u)
    {
        if (cmd.type == UART_CMD_SET_TABLE)
        {
            if (cmd.tableIndex < TABLE_COUNT)
            {
                g_activeTable = cmd.tableIndex;
                EEPROM_SaveActiveTable(g_activeTable);
            }
        }
        else if (cmd.type == UART_CMD_SET_TABLE2_VALUES)
        {
            g_tables[2] = cmd.table;
            if (g_tables[2].t_ms > TIME_MAX_MS)
            {
                g_tables[2].t_ms = 0u;
            }
            EEPROM_SaveTable(2u, &g_tables[2]);
            g_activeTable = 2u;
            EEPROM_SaveActiveTable(g_activeTable);
            g_lastBlinkMs = Platform_GetMs();
            g_blinkPhase = 0u;
        }
    }

    UART_DropLine();
}
