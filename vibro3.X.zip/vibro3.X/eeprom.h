#ifndef EEPROM_H
#define EEPROM_H

#include "types.h"

#define EE_MAGIC_ADDR      0u
#define EE_ACTIVE_TABLE    1u
#define EE_MAGIC_VALUE     0x5Au
#define EE_TABLE_BASE      16u
#define EE_TABLE_SIZE      10u

void EEPROM_InitDefaults(PARAM_TABLE *tables, BYTE *activeTable);
void EEPROM_SaveActiveTable(BYTE activeTable);
void EEPROM_SaveTable(BYTE index, const PARAM_TABLE *table);
void EEPROM_LoadTable(BYTE index, PARAM_TABLE *table);

#endif
