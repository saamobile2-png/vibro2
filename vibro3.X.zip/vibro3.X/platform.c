#include <xc.h>
#include "types.h"
#include "platform.h"
#include "uart.h"

static volatile DWORD g_ms = 0ul;
static volatile WORD  g_freqHz = 0u;
static volatile BYTE  g_freqReady = 0u;
static volatile BYTE  g_freqActive = 0u;
static volatile WORD  g_lastDelta = 0u;
static volatile WORD  g_t1Prev = 0u;
static volatile WORD  g_noPulseMs = 0u;

#define TMR0_PRELOAD_50PULSES 206u
#define TMR2_PERIOD_1MS       62u
#define FREQ_NUMERATOR_50P    12500000ul

static WORD Platform_ReadTimer1(void)
{
    WORD v;
    BYTE h;
    BYTE l;

    h = TMR1H;
    l = TMR1L;
    v = ((WORD)h << 8) | (WORD)l;
    return v;
}

void interrupt ISR(void)
{
    if (PIR1bits.TMR2IF)
    {
        PIR1bits.TMR2IF = 0;
        g_ms++;

        if (g_freqActive != 0u)
        {
            if (g_noPulseMs < 1000u)
            {
                g_noPulseMs++;
            }
        }
    }

    if (INTCONbits.TMR0IF)
    {
        WORD t1;
        WORD dt;

        INTCONbits.TMR0IF = 0;
        TMR0 = TMR0_PRELOAD_50PULSES;

        if (g_freqActive != 0u)
        {
            t1 = Platform_ReadTimer1();
            dt = (WORD)(t1 - g_t1Prev);
            g_t1Prev = t1;
            g_noPulseMs = 0u;

            if (dt != 0u)
            {
                g_lastDelta = dt;
                g_freqHz = (WORD)(FREQ_NUMERATOR_50P / (DWORD)dt);
                g_freqReady = 1u;
            }
        }
    }

    if (PIR1bits.RCIF)
    {
        if (RCSTAbits.OERR)
        {
            RCSTAbits.CREN = 0;
            RCSTAbits.CREN = 1;
        }

        if (PIR1bits.RCIF)
        {
            UART_RxISR((BYTE)RCREG);
        }
    }
}

void Platform_Init(void)
{
    /* ���������� ��������� 1 ��� */
    OSCCONbits.SCS = 0b10;
    OSCCONbits.IRCF = 0b1011;
    OSCCONbits.SPLLEN = 0;

    ANSELA = 0x02;
    ANSELB = 0x00;

    TRISA = 0x1F;
    TRISB = 0x03;

    LATA = 0xC0;
    LATB = 0x00;

    /* Timer0 ��� ������� ������� �� RA4/T0CKI */
    OPTION_REGbits.T0CS = 1;
    OPTION_REGbits.T0SE = 0;
    OPTION_REGbits.PSA  = 1;
    OPTION_REGbits.nWPUEN = 1;

    TMR0 = TMR0_PRELOAD_50PULSES;
    INTCONbits.TMR0IF = 0;
    INTCONbits.TMR0IE = 1;

    /* Timer1 - ������������ ������ ���� ���������, Finst=250 ���, 1 ���=4 ��� */
    T1CONbits.TMR1CS = 0b00;
    T1CONbits.T1CKPS = 0b00;
    T1CONbits.nT1SYNC = 1;
    TMR1H = 0u;
    TMR1L = 0u;
    PIR1bits.TMR1IF = 0;
    PIE1bits.TMR1IE = 0;
    T1CONbits.TMR1ON = 1;

    /* Timer2 - ��������� ��� ~1 �� */
    T2CONbits.T2CKPS = 0b01;   /* 1:4 */
    T2CONbits.TOUTPS = 0b0000; /* 1:1 */
    PR2 = TMR2_PERIOD_1MS;
    TMR2 = 0u;
    PIR1bits.TMR2IF = 0;
    PIE1bits.TMR2IE = 1;
    T2CONbits.TMR2ON = 1;

    /* ���������� �� ��������� ��������� */
    Platform_SetGreenLed(FALSE);
    Platform_SetRedLed(FALSE);
    Platform_SetNormalCurrentMax(FALSE);
    Platform_SetAlarmMode(FALSE);
    Platform_SetAlarmCurrent(FALSE);

    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;
}

DWORD Platform_GetMs(void)
{
    return g_ms;
}

void Platform_FreqStart(void)
{
    di();
    TMR0 = TMR0_PRELOAD_50PULSES;
    INTCONbits.TMR0IF = 0;
    TMR1H = 0u;
    TMR1L = 0u;
    g_t1Prev = 0u;
    g_lastDelta = 0u;
    g_freqHz = 0u;
    g_freqReady = 0u;
    g_noPulseMs = 0u;
    g_freqActive = 1u;
    ei();
}

BYTE Platform_FreqReady(void)
{
    if (g_freqActive == 0u)
    {
        return TRUE;
    }

    if (g_freqReady != 0u)
    {
        return TRUE;
    }

    if (g_noPulseMs >= 200u)
    {
        return TRUE;
    }

    return FALSE;
}

WORD Platform_FreqGetHz(void)
{
    WORD result;

    di();
    if (g_noPulseMs >= 200u)
    {
        result = 0u;
    }
    else
    {
        result = g_freqHz;
    }
    g_freqReady = 0u;
    g_freqActive = 0u;
    ei();

    return result;
}

BYTE Platform_ReadRA0(void)
{
    return (BYTE)PORTAbits.RA0;
}

BYTE Platform_ReadRA2(void)
{
    return (BYTE)PORTAbits.RA2;
}

BYTE Platform_ReadRA3(void)
{
    return (BYTE)PORTAbits.RA3;
}

BYTE Platform_ReadRB0(void)
{
    return (BYTE)PORTBbits.RB0;
}

void Platform_SetGreenLed(BYTE on)
{
    if (on != 0u)
    {
        LATAbits.LATA6 = 0;
    }
    else
    {
        LATAbits.LATA6 = 1;
    }
}

void Platform_SetRedLed(BYTE on)
{
    if (on != 0u)
    {
        LATAbits.LATA7 = 0;
    }
    else
    {
        LATAbits.LATA7 = 1;
    }
}

void Platform_SetNormalCurrentMax(BYTE on)
{
    if (on != 0u)
    {
        LATBbits.LATB6 = 1;
    }
    else
    {
        LATBbits.LATB6 = 0;
    }
}

void Platform_SetAlarmMode(BYTE on)
{
    if (on != 0u)
    {
        LATBbits.LATB4 = 1;
    }
    else
    {
        LATBbits.LATB4 = 0;
    }
}

void Platform_SetAlarmCurrent(BYTE on)
{
    if (on != 0u)
    {
        LATBbits.LATB3 = 1;
    }
    else
    {
        LATBbits.LATB3 = 0;
    }
}

void Platform_Task1ms(void)
{
    /* ������ */
}
