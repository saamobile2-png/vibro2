#ifndef PLATFORM_H
#define PLATFORM_H

#include "types.h"

void Platform_Init(void);
void Platform_Task1ms(void);

DWORD Platform_GetMs(void);

/* ��������� ������� */
void Platform_FreqStart(void);
BYTE Platform_FreqReady(void);
WORD Platform_FreqGetHz(void);

/* ����� */
BYTE Platform_ReadRA0(void);
BYTE Platform_ReadRA2(void);
BYTE Platform_ReadRA3(void);
BYTE Platform_ReadRB0(void);

/* ������ */
void Platform_SetGreenLed(BYTE on);
void Platform_SetRedLed(BYTE on);
void Platform_SetNormalCurrentMax(BYTE on);
void Platform_SetAlarmMode(BYTE on);
void Platform_SetAlarmCurrent(BYTE on);

#endif
