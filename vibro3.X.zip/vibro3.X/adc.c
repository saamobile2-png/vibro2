#include <xc.h>
#include "types.h"
#include "adc.h"
#define _XTAL_FREQ 1000000 // Select your XTAL

void ADC_Init(void)
{
    TRISAbits.TRISA1 = 1;
    ANSELAbits.ANSA1 = 1;

    ADCON0bits.CHS = 0b00001;
    ADCON1 = 0b11010000;
    ADCON0bits.ADON = 1;
}

WORD ADC_ReadAN1(void)
{
    ADCON0bits.CHS = 0b00001;
    __delay_us(10);
    ADCON0bits.GO_nDONE = 1;
    while (ADCON0bits.GO_nDONE != 0)
    {
    }
    return (WORD)(((WORD)ADRESH << 8) | ADRESL);
}

ADC_POSITION ADC_GetPosition(WORD adcValue)
{
    if (adcValue <= ADC_POS1_MAX)
    {
        return ADC_POS_1;
    }

    if ((adcValue >= ADC_POS2_MIN) && (adcValue <= ADC_POS2_MAX))
    {
        return ADC_POS_2;
    }

    if (adcValue >= ADC_POS3_MIN)
    {
        return ADC_POS_3;
    }

    return ADC_POS_UNKNOWN;
}

WORD ADC_ToTimeMs(WORD adcValue)
{
    WORD t;

    t = (WORD)(((DWORD)adcValue * (DWORD)TIME_MAX_MS) / 1023ul);
    return t;
}
