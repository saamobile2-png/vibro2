#include <xc.h>
#include "types.h"
#include "eeprom.h"

static BYTE EEPROM_ReadByte(BYTE addr)
{
    EEADRL = addr;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.RD = 1;
    return EEDATL;
}

static void EEPROM_WriteByte(BYTE addr, BYTE value)
{
    EEADRL = addr;
    EEDATL = value;

    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;

    INTCONbits.GIE = 0;
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    INTCONbits.GIE = 1;

    while (EECON1bits.WR != 0)
    {
    }

    EECON1bits.WREN = 0;
}

static WORD EEPROM_ReadWord(BYTE addr)
{
    WORD v;
    v  = (WORD)EEPROM_ReadByte(addr);
    v |= ((WORD)EEPROM_ReadByte(addr + 1u) << 8);
    return v;
}

static void EEPROM_WriteWord(BYTE addr, WORD value)
{
    EEPROM_WriteByte(addr, (BYTE)(value & 0xFFu));
    EEPROM_WriteByte(addr + 1u, (BYTE)((value >> 8) & 0xFFu));
}

static BYTE EEPROM_TableBase(BYTE index)
{
    return (BYTE)(EE_TABLE_BASE + (BYTE)(index * EE_TABLE_SIZE));
}

void EEPROM_LoadTable(BYTE index, PARAM_TABLE *table)
{
    BYTE base;
    if (index >= TABLE_COUNT)
    {
        return;
    }

    base = EEPROM_TableBase(index);
    table->f0 = EEPROM_ReadWord(base + 0u);
    table->f1 = EEPROM_ReadWord(base + 2u);
    table->f2 = EEPROM_ReadWord(base + 4u);
    table->f3 = EEPROM_ReadWord(base + 6u);
    table->t_ms = EEPROM_ReadWord(base + 8u);
}

void EEPROM_SaveTable(BYTE index, const PARAM_TABLE *table)
{
    BYTE base;
    if (index >= TABLE_COUNT)
    {
        return;
    }

    base = EEPROM_TableBase(index);
    EEPROM_WriteWord(base + 0u, table->f0);
    EEPROM_WriteWord(base + 2u, table->f1);
    EEPROM_WriteWord(base + 4u, table->f2);
    EEPROM_WriteWord(base + 6u, table->f3);
    EEPROM_WriteWord(base + 8u, table->t_ms);
}

void EEPROM_SaveActiveTable(BYTE activeTable)
{
    EEPROM_WriteByte(EE_ACTIVE_TABLE, activeTable);
}

void EEPROM_InitDefaults(PARAM_TABLE *tables, BYTE *activeTable)
{
    BYTE i;
    BYTE valid1;
    BYTE valid2;
    BYTE storedActive;

    valid1 = EEPROM_ReadByte(EE_MAGIC_ADDR);

    tables[0].f0 = 750u;
    tables[0].f1 = 930u;
    tables[0].f2 = 990u;
    tables[0].f3 = 1300u;
    tables[0].t_ms = 0u;

    if (valid1 != EE_MAGIC_VALUE)
    {
        tables[1] = tables[0];
        tables[2] = tables[1];
        tables[2].t_ms = 0u;

        EEPROM_WriteByte(EE_MAGIC_ADDR, EE_MAGIC_VALUE);
        for (i = 0u; i < TABLE_COUNT; i++)
        {
            EEPROM_SaveTable(i, &tables[i]);
        }
        EEPROM_SaveActiveTable(0u);
        *activeTable = 0u;
        return;
    }

    EEPROM_LoadTable(0u, &tables[0]);
    EEPROM_LoadTable(1u, &tables[1]);
    EEPROM_LoadTable(2u, &tables[2]);

    valid1 = (BYTE)((tables[1].f0 < tables[1].f3) ? 1u : 0u);
    valid2 = (BYTE)((tables[2].f0 < tables[2].f3) ? 1u : 0u);

    if (valid1 == 0u)
    {
        tables[1] = tables[0];
    }

    if (valid2 == 0u)
    {
        tables[2] = tables[1];
        if (tables[2].t_ms > TIME_MAX_MS)
        {
            tables[2].t_ms = 0u;
        }
    }

    storedActive = EEPROM_ReadByte(EE_ACTIVE_TABLE);
    if (storedActive >= TABLE_COUNT)
    {
        storedActive = 0u;
    }

    *activeTable = storedActive;
}
