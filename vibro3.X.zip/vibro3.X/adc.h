#ifndef ADC_H
#define ADC_H

#include "types.h"

void ADC_Init(void);
WORD ADC_ReadAN1(void);
ADC_POSITION ADC_GetPosition(WORD adcValue);
WORD ADC_ToTimeMs(WORD adcValue);

#endif
