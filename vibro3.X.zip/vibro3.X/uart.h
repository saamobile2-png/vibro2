#ifndef UART_H
#define UART_H

#include "types.h"

#define UART_RX_BUF_SIZE 64u

typedef enum
{
    UART_CMD_NONE = 0,
    UART_CMD_SET_TABLE,
    UART_CMD_SET_TABLE2_VALUES
} UART_CMD_TYPE;

typedef struct
{
    UART_CMD_TYPE type;
    BYTE tableIndex;
    PARAM_TABLE table;
} UART_COMMAND;

void UART_Init(void);
void UART_RxISR(BYTE c);
BYTE UART_HasLine(void);
void UART_DropLine(void);
BYTE UART_ParseLine(UART_COMMAND *cmd);

void UART_PutChar(char c);
void UART_PutCRLF(void);
void UART_PutString(const char *s);
void UART_PutWord(WORD v);

#endif
