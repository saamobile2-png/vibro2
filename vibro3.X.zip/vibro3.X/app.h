#ifndef APP_H
#define APP_H

#include "types.h"

void APP_Init(void);
void APP_Task(void);

#endif
