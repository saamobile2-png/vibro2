#include <xc.h>
#include "types.h"
#include "platform.h"
#include "adc.h"
#include "uart.h"
#include "app.h"

/* ���������������� ���� */
#pragma config FOSC = INTOSC
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config MCLRE = ON
#pragma config CP = OFF
#pragma config CPD = OFF
#pragma config BOREN = OFF
#pragma config CLKOUTEN = OFF
#pragma config IESO = OFF
#pragma config FCMEN = OFF

#pragma config WRT = OFF
#pragma config PLLEN = OFF
#pragma config STVREN = ON
#pragma config BORV = HI
#pragma config LVP = OFF

void main(void)
{
    Platform_Init();
    ADC_Init();
    UART_Init();
    APP_Init();

    for(;;)
    {
        APP_Task();
    }
}
